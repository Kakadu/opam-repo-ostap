let ocaml_version = "3.10"
let ocaml_name = "ocaml"
let ast_impl_magic_number = "Caml1999M011"
let ast_intf_magic_number = "Caml1999N010"
