LOG (Printf.printf "test log message\n");
