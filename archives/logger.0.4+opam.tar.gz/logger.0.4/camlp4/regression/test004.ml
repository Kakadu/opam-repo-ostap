LOG[test002] (Printf.printf "first test log message\n");
LOG[test003] (Printf.printf "second test log message\n");
LOG[test003,test002] (Printf.printf "second and first test log message\n");
LOG (Printf.printf "all test log message\n");
